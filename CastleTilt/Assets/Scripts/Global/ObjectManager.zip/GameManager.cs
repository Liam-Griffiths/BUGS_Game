using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour 
{
	public GUIText guiTimer;
	public CastleController castle;
	public float levelTimer;
	private float startTime;

	public GameObject EnvironmentParent;
	public Transform SpawnPoint;

	void Start () 
	{
		CastleSelection script = GameObject.FindWithTag("GLOBAL_SCRIPTS").GetComponent<CastleSelection>();
		GameObject newCastle = script.FindCastle();
		GameObject instanceCastle = (GameObject)Instantiate(newCastle, Vector3.zero, Quaternion.identity);

		instanceCastle.transform.parent = EnvironmentParent.transform;
		instanceCastle.transform.position = SpawnPoint.position;

		castle = instanceCastle.GetComponent<CastleController>();



		/*guiTimer = GameObject.Find("GUI Game Timer").GetComponent<GUIText>();
		guiTimer.fontSize = (int)(Screen.width * 0.03f);*/
		startTime = Time.time;
	}

   public CastleController castleCon()
	{
		return castle;
	}

	void Update () 
	{
		/*if(castle.currentHealth <= 0)
		{
			WinScreen();
		}

		float newTime = levelTimer - Time.time + startTime;
		guiTimer.text = ((int)newTime).ToString();

		if(newTime < 0)
		{
			LoseScreen();
		}
	*/
	}
	/*
	private void WinScreen()
	{
		Application.LoadLevel(2);
	}

	
	private void LoseScreen()
	{
		Application.LoadLevel(3);
	}*/
}
